﻿using ModelBindingAndDBCode.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ModelBindingAndDBCode.Controllers
{
    public class EmployeesController : Controller
    {
        // GET: Employees
        public ActionResult Index()
        {
            List<Employee> objEmp = new List<Employee>();
            //objEmp.Add(new Employee { EmpNo = 1, Name = "aakash", Basic = 1234, DeptNo =10});
            //objEmp.Add(new Employee { EmpNo = 2, Name = "shubham", Basic = 1234, DeptNo = 20 });
            //objEmp.Add(new Employee { EmpNo = 3, Name = "Mahesh", Basic = 1234, DeptNo = 30 });
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";

            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Employees";


            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                objEmp.Add(new Employee { EmpNo =Convert.ToInt32(dr["EmpNo"]), Name = Convert.ToString(dr["Name"]), Basic = Convert.ToInt32(dr["Basic"]) , DeptNo = Convert.ToInt32(dr["DeptNo"])});

            }
            dr.Close();

            cn.Close();

            return View(objEmp);
        }

        // GET: Employees/Details/5
        public ActionResult Details(int id=0)
        {
             Employee objEmp = new Employee();
            //    objEmp.EmpNo = 123;
            //    objEmp.Name = "Aakash";
            //    objEmp.Basic = 12345;
            //    objEmp.DeptNo = 10;
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";

            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Employees where EmpNo= "+id;

            

            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                objEmp.EmpNo = Convert.ToInt32(dr["EmpNo"]);
                objEmp.Name = dr["Name"].ToString();
                objEmp.Basic = Convert.ToInt32(dr["Basic"]);
                objEmp.DeptNo = Convert.ToInt32(dr["DeptNo"]);

            }
            

          

            return View(objEmp);
            dr.Close();

            cn.Close();
        }

        // GET: Employees/Create
        public ActionResult Create()
        {
            Employee objEmp = new Employee();
            return View(objEmp);
        }

        // POST: Employees/Create
        [HttpPost]
        public ActionResult Create(Employee objEmp)
        {
            try
            {
                // TODO: Add insert logic here
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";

                cn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;

                cmd.CommandText = "insert into Employees values(@EmpNo,@Name,@Basic,@DeptNo)";

                cmd.Parameters.AddWithValue("@EmpNo", objEmp.EmpNo);
                cmd.Parameters.AddWithValue("@Name", objEmp.Name);
                cmd.Parameters.AddWithValue("@Basic", objEmp.Basic);
                cmd.Parameters.AddWithValue("@DeptNo", objEmp.DeptNo);

                //MessageBox.Show(cmd.CommandText);
                
                    cmd.ExecuteNonQuery();

                cn.Close();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employees/Edit/5
        public ActionResult Edit(int id=0)
        {
            Employee objEmp = new Employee();
            //    objEmp.EmpNo = 123;
            //    objEmp.Name = "Aakash";
            //    objEmp.Basic = 12345;
            //    objEmp.DeptNo = 10;
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";

            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Employees where EmpNo= " + id;



            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                objEmp.EmpNo = Convert.ToInt32(dr["EmpNo"]);
                objEmp.Name = dr["Name"].ToString();
                objEmp.Basic = Convert.ToInt32(dr["Basic"]);
                objEmp.DeptNo = Convert.ToInt32(dr["DeptNo"]);

            }

            return View(objEmp);
            dr.Close();

            cn.Close();

        }

        // POST: Employees/Edit/5
        [HttpPost]
        //public ActionResult Edit(int? id, FormCollection collection)
        public ActionResult Edit(int? id, Employee objEmp)
        {
            try
            {
                // TODO: Add update logic here

                //int EmpNo= Convert.ToInt32(collection["EmpNo"]);
                // string Name=collection["Name"];
                // string Name=objEmp.Name;
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";

                cn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update employees set Name=@Name,Basic=@Basic,DeptNo=@DeptNo where EmpNo=@EmpNo";

           
                cmd.Parameters.AddWithValue("@Name", objEmp.Name);
                cmd.Parameters.AddWithValue("@Basic", objEmp.Basic);
                cmd.Parameters.AddWithValue("@DeptNo", objEmp.DeptNo);
                cmd.Parameters.AddWithValue("@EmpNo", objEmp.EmpNo);

                cmd.ExecuteNonQuery();

                cn.Close();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employees/Delete/5
        public ActionResult Delete(int id)
        {
            //Employee objEmp = new Employee();
            //objEmp.EmpNo = 123;
            //objEmp.Name = "Aakash";
            //objEmp.Basic = 12345;
            //objEmp.DeptNo = 10;
            //return View(objEmp);


            Employee objEmp = new Employee();
          
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";

            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Employees where EmpNo= " + id;



            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                objEmp.EmpNo = Convert.ToInt32(dr["EmpNo"]);
                objEmp.Name = dr["Name"].ToString();
                objEmp.Basic = Convert.ToInt32(dr["Basic"]);
                objEmp.DeptNo = Convert.ToInt32(dr["DeptNo"]);

            }

            return View(objEmp);
            dr.Close();

            cn.Close();
        }

        // POST: Employees/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Employee objEmp)
        {
            try
            {
                // TODO: Add delete logic here
               // Employee objEmp = new Employee();

                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=true";

                cn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from Employees where EmpNo= " + id;
               // cmd.CommandText = "delete from Employees where EmpNo=@EmpNo ";
               // cmd.Parameters.AddWithValue("@EmpNo", id);
                cmd.ExecuteNonQuery();

                cn.Close();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
